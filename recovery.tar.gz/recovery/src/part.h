#ifndef _PART_H
#define _PART_H

class Part {
   public:
    virtual void Run();
    virtual ~Part();
};

#endif