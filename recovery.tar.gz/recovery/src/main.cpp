#include "car.h"

int main() {
    Car c;
    c.Run();
    return 0;
}