#include "part.h"

void Part::Run(){};

Part::~Part() {}