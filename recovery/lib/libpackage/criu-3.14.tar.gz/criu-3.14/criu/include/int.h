#ifndef __CR_INC_INT_H__
#define __CR_INC_INT_H__
#include "asm/int.h"
#endif
