Raspicam for capturing images
